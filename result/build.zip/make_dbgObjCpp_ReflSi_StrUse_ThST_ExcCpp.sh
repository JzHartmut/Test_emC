# call of compile, link and execute for Test emC_Base with gcc

if test -f make_dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp.sh; then cd ..; fi  #is in build directory, should call from root
pwd
if ! test -d build/result; then mkdir build/result; fi
if ! test -d build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp; then mkdir build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp; fi
java -cp libs/vishiaBase.jar org.vishia.checkDeps_C.CheckDeps --@build/deps_dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp.args
rm -f build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc*.txt
#rm -r Debug  #for test
echo dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp: Compile with -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  1> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
echo dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp: Compile with -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp 

echo ==== gcc emC/Base/Assert_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Assert_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Assert_emC.o src/main/cpp/src_emC/emC/Base/Assert_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Assert_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Assert_emC.o; then 
    echo gcc ERROR: emC/Base/Assert_emC.c
    echo ERROR: emC/Base/Assert_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/Assert_emC.c
  fi
else
  echo exist: emC/Base/Assert_emC.c
fi  

echo ==== gcc emC/Base/MemC_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/MemC_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/MemC_emC.o src/main/cpp/src_emC/emC/Base/MemC_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/MemC_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/MemC_emC.o; then 
    echo gcc ERROR: emC/Base/MemC_emC.c
    echo ERROR: emC/Base/MemC_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/MemC_emC.c
  fi
else
  echo exist: emC/Base/MemC_emC.c
fi  

echo ==== gcc emC/Base/StringBase_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/StringBase_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/StringBase_emC.o src/main/cpp/src_emC/emC/Base/StringBase_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/StringBase_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/StringBase_emC.o; then 
    echo gcc ERROR: emC/Base/StringBase_emC.c
    echo ERROR: emC/Base/StringBase_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/StringBase_emC.c
  fi
else
  echo exist: emC/Base/StringBase_emC.c
fi  

echo ==== gcc emC/Base/ObjectSimple_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectSimple_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectSimple_emC.o src/main/cpp/src_emC/emC/Base/ObjectSimple_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectSimple_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectSimple_emC.o; then 
    echo gcc ERROR: emC/Base/ObjectSimple_emC.c
    echo ERROR: emC/Base/ObjectSimple_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/ObjectSimple_emC.c
  fi
else
  echo exist: emC/Base/ObjectSimple_emC.c
fi  

echo ==== gcc emC/Base/Object_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Object_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Object_emC.o src/main/cpp/src_emC/emC/Base/Object_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Object_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Object_emC.o; then 
    echo gcc ERROR: emC/Base/Object_emC.c
    echo ERROR: emC/Base/Object_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/Object_emC.c
  fi
else
  echo exist: emC/Base/Object_emC.c
fi  

echo ==== gcc emC/Base/ObjectJcpp_emC.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectJcpp_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectJcpp_emC.o src/main/cpp/src_emC/emC/Base/ObjectJcpp_emC.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectJcpp_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectJcpp_emC.o; then 
    echo gcc ERROR: emC/Base/ObjectJcpp_emC.cpp
    echo ERROR: emC/Base/ObjectJcpp_emC.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/ObjectJcpp_emC.cpp
  fi
else
  echo exist: emC/Base/ObjectJcpp_emC.cpp
fi  

echo ==== gcc emC/Base/Exception_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Exception_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Exception_emC.o src/main/cpp/src_emC/emC/Base/Exception_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Exception_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Exception_emC.o; then 
    echo gcc ERROR: emC/Base/Exception_emC.c
    echo ERROR: emC/Base/Exception_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/Exception_emC.c
  fi
else
  echo exist: emC/Base/Exception_emC.c
fi  

echo ==== gcc emC/Base/ExceptionCpp_emC.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ExceptionCpp_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ExceptionCpp_emC.o src/main/cpp/src_emC/emC/Base/ExceptionCpp_emC.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ExceptionCpp_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ExceptionCpp_emC.o; then 
    echo gcc ERROR: emC/Base/ExceptionCpp_emC.cpp
    echo ERROR: emC/Base/ExceptionCpp_emC.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/ExceptionCpp_emC.cpp
  fi
else
  echo exist: emC/Base/ExceptionCpp_emC.cpp
fi  

echo ==== gcc emC/Base/ReflectionBaseTypes_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ReflectionBaseTypes_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ReflectionBaseTypes_emC.o src/main/cpp/src_emC/emC/Base/ReflectionBaseTypes_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ReflectionBaseTypes_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ReflectionBaseTypes_emC.o; then 
    echo gcc ERROR: emC/Base/ReflectionBaseTypes_emC.c
    echo ERROR: emC/Base/ReflectionBaseTypes_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Base/ReflectionBaseTypes_emC.c
  fi
else
  echo exist: emC/Base/ReflectionBaseTypes_emC.c
fi  

echo ==== gcc emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.o src/main/cpp/src_emC/emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.o; then 
    echo gcc ERROR: emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.c
    echo ERROR: emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.c
  fi
else
  echo exist: emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.c
fi  

echo ==== gcc emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.o src/main/cpp/src_emC/emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.o; then 
    echo gcc ERROR: emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.c
    echo ERROR: emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.c
  fi
else
  echo exist: emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.c
fi  

echo ==== gcc emC/Test/testAssert_C.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert_C.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert_C.o src/main/cpp/src_emC/emC/Test/testAssert_C.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert_C.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert_C.o; then 
    echo gcc ERROR: emC/Test/testAssert_C.c
    echo ERROR: emC/Test/testAssert_C.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Test/testAssert_C.c
  fi
else
  echo exist: emC/Test/testAssert_C.c
fi  

echo ==== gcc emC/Test/testAssert.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert.o src/main/cpp/src_emC/emC/Test/testAssert.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert.o; then 
    echo gcc ERROR: emC/Test/testAssert.cpp
    echo ERROR: emC/Test/testAssert.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC/Test/testAssert.cpp
  fi
else
  echo exist: emC/Test/testAssert.cpp
fi  

echo ==== gcc src/test/cpp/emC_TestAll/outTestConditions.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/src/test/cpp/emC_TestAll/outTestConditions.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/src/test/cpp/emC_TestAll
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/src/test/cpp/emC_TestAll/outTestConditions.o src/test/cpp/emC_TestAll/outTestConditions.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/src/test/cpp/emC_TestAll/outTestConditions.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/src/test/cpp/emC_TestAll/outTestConditions.o; then 
    echo gcc ERROR: src/test/cpp/emC_TestAll/outTestConditions.c
    echo ERROR: src/test/cpp/emC_TestAll/outTestConditions.c >> gcc_nocc.txt; 
  else
    echo gcc ok: src/test/cpp/emC_TestAll/outTestConditions.c
  fi
else
  echo exist: src/test/cpp/emC_TestAll/outTestConditions.c
fi  

echo ==== gcc emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.o src/main/cpp/src_emC/emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.o; then 
    echo gcc ERROR: emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.c
    echo ERROR: emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.c
  fi
else
  echo exist: emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.c
fi  

echo ==== gcc emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.o src/main/cpp/src_emC/emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.o; then 
    echo gcc ERROR: emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.c
    echo ERROR: emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.c
  fi
else
  echo exist: emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.c
fi  

echo ==== gcc emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.o src/main/cpp/src_emC/emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.o; then 
    echo gcc ERROR: emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.c
    echo ERROR: emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.c
  fi
else
  echo exist: emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.c
fi  

echo ==== gcc emC_srcApplSpec/applConv/LogException_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/LogException_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/LogException_emC.o src/main/cpp/src_emC/emC_srcApplSpec/applConv/LogException_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/LogException_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/LogException_emC.o; then 
    echo gcc ERROR: emC_srcApplSpec/applConv/LogException_emC.c
    echo ERROR: emC_srcApplSpec/applConv/LogException_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcApplSpec/applConv/LogException_emC.c
  fi
else
  echo exist: emC_srcApplSpec/applConv/LogException_emC.c
fi  

echo ==== gcc emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.o src/main/cpp/src_emC/emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.o; then 
    echo gcc ERROR: emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.c
    echo ERROR: emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.c
  fi
else
  echo exist: emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.c
fi  

echo ==== gcc emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/hw_Intel_x86_Gcc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.o src/main/cpp/src_emC/emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.o; then 
    echo gcc ERROR: emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.c
    echo ERROR: emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.c
  fi
else
  echo exist: emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.c
fi  

echo ==== gcc emC_srcOSALspec/os_LinuxGcc/os_endian.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_endian.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_endian.o src/main/cpp/src_emC/emC_srcOSALspec/os_LinuxGcc/os_endian.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_endian.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_endian.o; then 
    echo gcc ERROR: emC_srcOSALspec/os_LinuxGcc/os_endian.c
    echo ERROR: emC_srcOSALspec/os_LinuxGcc/os_endian.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcOSALspec/os_LinuxGcc/os_endian.c
  fi
else
  echo exist: emC_srcOSALspec/os_LinuxGcc/os_endian.c
fi  

echo ==== gcc emC_srcOSALspec/os_LinuxGcc/os_error.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_error.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_error.o src/main/cpp/src_emC/emC_srcOSALspec/os_LinuxGcc/os_error.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_error.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_error.o; then 
    echo gcc ERROR: emC_srcOSALspec/os_LinuxGcc/os_error.c
    echo ERROR: emC_srcOSALspec/os_LinuxGcc/os_error.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcOSALspec/os_LinuxGcc/os_error.c
  fi
else
  echo exist: emC_srcOSALspec/os_LinuxGcc/os_error.c
fi  

echo ==== gcc emC_srcOSALspec/os_LinuxGcc/os_file.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_file.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_file.o src/main/cpp/src_emC/emC_srcOSALspec/os_LinuxGcc/os_file.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_file.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_file.o; then 
    echo gcc ERROR: emC_srcOSALspec/os_LinuxGcc/os_file.c
    echo ERROR: emC_srcOSALspec/os_LinuxGcc/os_file.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcOSALspec/os_LinuxGcc/os_file.c
  fi
else
  echo exist: emC_srcOSALspec/os_LinuxGcc/os_file.c
fi  

echo ==== gcc emC_srcOSALspec/os_LinuxGcc/os_mem.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_mem.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_mem.o src/main/cpp/src_emC/emC_srcOSALspec/os_LinuxGcc/os_mem.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_mem.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_mem.o; then 
    echo gcc ERROR: emC_srcOSALspec/os_LinuxGcc/os_mem.c
    echo ERROR: emC_srcOSALspec/os_LinuxGcc/os_mem.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcOSALspec/os_LinuxGcc/os_mem.c
  fi
else
  echo exist: emC_srcOSALspec/os_LinuxGcc/os_mem.c
fi  

echo ==== gcc emC_srcOSALspec/os_LinuxGcc/os_time.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_time.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_time.o src/main/cpp/src_emC/emC_srcOSALspec/os_LinuxGcc/os_time.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_time.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_time.o; then 
    echo gcc ERROR: emC_srcOSALspec/os_LinuxGcc/os_time.c
    echo ERROR: emC_srcOSALspec/os_LinuxGcc/os_time.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_srcOSALspec/os_LinuxGcc/os_time.c
  fi
else
  echo exist: emC_srcOSALspec/os_LinuxGcc/os_time.c
fi  

echo ==== gcc emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.o src/test/cpp/emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.o; then 
    echo gcc ERROR: emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.cpp
    echo ERROR: emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.cpp
  fi
else
  echo exist: emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.cpp
fi  

echo ==== gcc emC_Test_ObjectJc/test_ObjectJcpp.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJcpp.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJcpp.o src/test/cpp/emC_Test_ObjectJc/test_ObjectJcpp.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJcpp.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJcpp.o; then 
    echo gcc ERROR: emC_Test_ObjectJc/test_ObjectJcpp.cpp
    echo ERROR: emC_Test_ObjectJc/test_ObjectJcpp.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_Test_ObjectJc/test_ObjectJcpp.cpp
  fi
else
  echo exist: emC_Test_ObjectJc/test_ObjectJcpp.cpp
fi  

echo ==== gcc emC_Test_ObjectJc/test_ObjectJc.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJc.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJc.o src/test/cpp/emC_Test_ObjectJc/test_ObjectJc.c 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJc.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJc.o; then 
    echo gcc ERROR: emC_Test_ObjectJc/test_ObjectJc.c
    echo ERROR: emC_Test_ObjectJc/test_ObjectJc.c >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_Test_ObjectJc/test_ObjectJc.c
  fi
else
  echo exist: emC_Test_ObjectJc/test_ObjectJc.c
fi  

echo ==== gcc emC_Test_Stacktrc_Exc/TestException.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_Stacktrc_Exc/TestException.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_Stacktrc_Exc
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_Stacktrc_Exc/TestException.o src/test/cpp/emC_Test_Stacktrc_Exc/TestException.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_Stacktrc_Exc/TestException.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_Stacktrc_Exc/TestException.o; then 
    echo gcc ERROR: emC_Test_Stacktrc_Exc/TestException.cpp
    echo ERROR: emC_Test_Stacktrc_Exc/TestException.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_Test_Stacktrc_Exc/TestException.cpp
  fi
else
  echo exist: emC_Test_Stacktrc_Exc/TestException.cpp
fi  

echo ==== gcc emC_Test_C_Cpp/test_stdArray.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/test_stdArray.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/test_stdArray.o src/test/cpp/emC_Test_C_Cpp/test_stdArray.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/test_stdArray.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/test_stdArray.o; then 
    echo gcc ERROR: emC_Test_C_Cpp/test_stdArray.cpp
    echo ERROR: emC_Test_C_Cpp/test_stdArray.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_Test_C_Cpp/test_stdArray.cpp
  fi
else
  echo exist: emC_Test_C_Cpp/test_stdArray.cpp
fi  

echo ==== gcc emC_Test_C_Cpp/TestVtblExplicit.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/TestVtblExplicit.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/TestVtblExplicit.o src/test/cpp/emC_Test_C_Cpp/TestVtblExplicit.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/TestVtblExplicit.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/TestVtblExplicit.o; then 
    echo gcc ERROR: emC_Test_C_Cpp/TestVtblExplicit.cpp
    echo ERROR: emC_Test_C_Cpp/TestVtblExplicit.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_Test_C_Cpp/TestVtblExplicit.cpp
  fi
else
  echo exist: emC_Test_C_Cpp/TestVtblExplicit.cpp
fi  

echo ==== gcc emC_TestAll/testBasics.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
if ! test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_TestAll/testBasics.o; then
  mkdir -p build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_TestAll
  gcc -O0 -Wall -c -Wa,-adhln -D DEF_ObjectJcpp_REFLECTION -D DEF_REFLECTION_SIMPLE -D DEF_StringJcCapab_USE -D DEF_ThreadContext_STACKTRC -D DEF_Exception_TRYCpp  -Isrc/test/ZmakeGcc/All_Test/applstdef_UseCCdef -D DEF_TESTBasics_emC  -Isrc/main/cpp/src_emC/emC_inclComplSpec/cc_Gcc -Isrc/test/cpp -Isrc/main/cpp/src_emC -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_TestAll/testBasics.o src/test/cpp/emC_TestAll/testBasics.cpp 1>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_TestAll/testBasics.lst 2>> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt 
  if test ! -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_TestAll/testBasics.o; then 
    echo gcc ERROR: emC_TestAll/testBasics.cpp
    echo ERROR: emC_TestAll/testBasics.cpp >> gcc_nocc.txt; 
  else
    echo gcc ok: emC_TestAll/testBasics.cpp
  fi
else
  echo exist: emC_TestAll/testBasics.cpp
fi  

if test -e build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emCBase_.test.exe; then rm -f test.exe; fi
g++ -o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emCBase_.test.exe build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Assert_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/MemC_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/StringBase_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectSimple_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Object_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ObjectJcpp_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/Exception_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ExceptionCpp_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Base/ReflectionBaseTypes_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ThreadContextUserBuffer_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ExceptionPrintStacktrace_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert_C.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC/Test/testAssert.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/src/test/cpp/emC_TestAll/outTestConditions.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ApplSimpleStop_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/fw_ThreadContextSimpleIntr.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/SimpleNumCNoExc/ThreadContextSingle_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/LogException_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcApplSpec/applConv/ObjectJc_allocStartup_emC.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/hw_Intel_x86_Gcc/os_atomic.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_endian.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_error.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_file.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_mem.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_srcOSALspec/os_LinuxGcc/os_time.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/testAll_ObjectJcpp_emCBase.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJcpp.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_ObjectJc/test_ObjectJc.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_Stacktrc_Exc/TestException.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/test_stdArray.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_Test_C_Cpp/TestVtblExplicit.o build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emC_TestAll/testBasics.o -lgcc_s -lgcc  1> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/ld_out.txt 2> build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/ld_err.txt            
echo view gcc_err.txt and ld_err.txt for warnings or errors if the test does not run.                                     

if ! test -f build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emCBase_.test.exe; then
echo ERROR build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emCBase_.test.exe not built. See linker output.
cat build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/gcc_err.txt
cat build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/ld_err.txt
echo ==========================
else  
echo ==== execute the test ====                  
build/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp/emCBase_.test.exe 1> build/result/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp.out 2> build/result/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp.err
echo ==== Test cases ==========
cat build/result/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp.out
echo
echo ==== Test failures =======
cat build/result/dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp.err
echo
echo ==========================
fi  
