                                                                                                                                                
  
echo all output > all.out
if test -d build; then cd build; fi
if test -f testAllBase.out; then rm testAllBase.out; fi
echo "==== new test select=;SE:}SE:{SE ====" >testAllBase.out
date >> testAllBase.out
echo "==================================" >>testAllBase.out
#All test cases

  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_SIMPLE" >> out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiSi_ReflNo_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflSi_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectSimple_emC" > out.txt
echo "#define DEF_ObjectJc_REFLREF" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSiRefl_ReflOffs_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_SIMPLE" > out.txt
echo "#define DEF_REFLECTION_NO" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjSimpl_ReflNo_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflSi_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflOffs_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJc_REFLREF" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjRefl_ReflFull_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflSi_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflOffs_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCpp_ReflFull_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_SIMPLE" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflSi_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_OFFS" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflOffs_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrNo_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrNo_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrNo_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrNo_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrNo_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_NO_StringJcCapabilities" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrNo_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrUse_ThSi_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrUse_ThSi_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_SIMPLE" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrUse_ThSi_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_NO" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrUse_ThST_ExcNo.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_longjmp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrUse_ThST_ExcJmp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  
  echo "#define DEF_ObjectJcpp_REFLECTION" > out.txt
echo "#define DEF_ObjectJc_OWNADDRESS" >> out.txt
echo "#define DEF_REFLECTION_FULL" >> out.txt
echo "#define DEF_StringJcCapab_USE" >> out.txt
echo "#define DEF_ThreadContext_STACKTRC" >> out.txt
echo "#define DEF_Exception_TRYCpp" >> out.txt

  ./make_dbgObjCppAdr_ReflFull_StrUse_ThST_ExcCpp.sh >>out.txt
  cat out.txt
  cat out.txt >> testAllBase.out
  read -n1 -r -p "Press any key to continue..."
